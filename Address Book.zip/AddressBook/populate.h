void populateAdressBook(AddressBook* addressBook);
